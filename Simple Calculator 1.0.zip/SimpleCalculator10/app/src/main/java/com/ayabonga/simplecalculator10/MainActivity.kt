package com.ayabonga.simplecalculator10

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var editNum1: EditText
    private lateinit var editNum2: EditText
    private lateinit var addIt: Button
    private lateinit var subtract: Button
    private lateinit var multiply: Button
    private lateinit var divide: Button
    private lateinit var cleartext: Button
    private var randomNumber = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        addingtwonumbers()
    }
    fun addingtwonumbers()
    {
        var num1 = findViewById<EditText>(R.id.editNum1)
        var num2 =findViewById<EditText>(R.id.editNum2)
        var button1 = findViewById<Button>(R.id.addIt)
        var subtractbutton =findViewById<Button>(R.id.subtract)
        var multiplybutton =findViewById<Button>(R.id.multiply)
        var dividebutton =findViewById<Button>(R.id.divide)
        var cleartextbutton =findViewById<Button>(R.id.cleartext)

        addIt.setOnClickListener {
            var addnum1: Int = editNum1.text.toString().toInt()
            var addnum2: Int = editNum2.text.toString().toInt()
            var result = addnum1 + addnum2

            Toast.makeText(this,"$result", Toast.LENGTH_SHORT).show()
        }
        subtract.setOnClickListener {
            var addnum1= num1.text.toString().toInt()
            var addnum2 = num2.text.toString() .toInt()
            var resultsubtract = addnum1 - addnum2

            Toast.makeText(this,"$resultsubtract", Toast.LENGTH_SHORT).show()
        }

        multiply.setOnClickListener {
            var addnum1= num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var resultmultiply = addnum1 * addnum2

            Toast.makeText(this,"$resultmultiply", Toast.LENGTH_SHORT).show()
        }

        divide.setOnClickListener {
            var addnum1= num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var resultdivide = addnum1 / addnum2

            android.widget.Toast.makeText(this,"$resultdivide", android.widget.Toast.LENGTH_SHORT).show()
        }
        cleartext.setOnClickListener {
            editNum1.setText("");
            editNum2.setText("");

            Toast.makeText(this,"Cleared", Toast.LENGTH_LONG).show()

        }



    }

}


